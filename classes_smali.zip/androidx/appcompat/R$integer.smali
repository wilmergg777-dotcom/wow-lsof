.class public final Landroidx/appcompat/R$integer;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "integer"
.end annotation


# static fields
.field public static abc_config_activityDefaultDur:I = 0x7f090000

.field public static abc_config_activityShortDur:I = 0x7f090001

.field public static cancel_button_image_alpha:I = 0x7f090002

.field public static config_tooltipAnimTime:I = 0x7f090003


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
