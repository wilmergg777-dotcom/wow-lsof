.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static action_bar:I = 0x7f080027

.field public static action_bar_activity_content:I = 0x7f080028

.field public static action_bar_container:I = 0x7f080029

.field public static action_bar_root:I = 0x7f08002a

.field public static action_bar_spinner:I = 0x7f08002b

.field public static action_bar_subtitle:I = 0x7f08002c

.field public static action_bar_title:I = 0x7f08002d

.field public static action_context_bar:I = 0x7f08002f

.field public static action_menu_divider:I = 0x7f080032

.field public static action_menu_presenter:I = 0x7f080033

.field public static action_mode_bar:I = 0x7f080034

.field public static action_mode_bar_stub:I = 0x7f080035

.field public static action_mode_close_button:I = 0x7f080036

.field public static activity_chooser_view_content:I = 0x7f080039

.field public static add:I = 0x7f08003a

.field public static alertTitle:I = 0x7f08003d

.field public static buttonPanel:I = 0x7f080049

.field public static checkbox:I = 0x7f08004b

.field public static checked:I = 0x7f08004c

.field public static content:I = 0x7f08004f

.field public static contentPanel:I = 0x7f080050

.field public static custom:I = 0x7f080051

.field public static customPanel:I = 0x7f080052

.field public static decor_content_parent:I = 0x7f080054

.field public static default_activity_button:I = 0x7f080055

.field public static edit_query:I = 0x7f080058

.field public static expand_activities_button:I = 0x7f08005b

.field public static expanded_menu:I = 0x7f08005c

.field public static group_divider:I = 0x7f08005f

.field public static home:I = 0x7f080061

.field public static icon:I = 0x7f080063

.field public static image:I = 0x7f080067

.field public static listMode:I = 0x7f08006e

.field public static list_item:I = 0x7f08006f

.field public static message:I = 0x7f080070

.field public static multiply:I = 0x7f080072

.field public static none:I = 0x7f080074

.field public static normal:I = 0x7f080075

.field public static off:I = 0x7f080079

.field public static on:I = 0x7f08007d

.field public static parentPanel:I = 0x7f080083

.field public static progress_circular:I = 0x7f080084

.field public static progress_horizontal:I = 0x7f080085

.field public static radio:I = 0x7f080086

.field public static screen:I = 0x7f080089

.field public static scrollIndicatorDown:I = 0x7f08008a

.field public static scrollIndicatorUp:I = 0x7f08008b

.field public static scrollView:I = 0x7f08008c

.field public static search_badge:I = 0x7f08008d

.field public static search_bar:I = 0x7f08008e

.field public static search_button:I = 0x7f08008f

.field public static search_close_btn:I = 0x7f080090

.field public static search_edit_frame:I = 0x7f080091

.field public static search_go_btn:I = 0x7f080092

.field public static search_mag_icon:I = 0x7f080093

.field public static search_plate:I = 0x7f080094

.field public static search_src_text:I = 0x7f080095

.field public static search_voice_btn:I = 0x7f080096

.field public static select_dialog_listview:I = 0x7f080097

.field public static shortcut:I = 0x7f080098

.field public static spacer:I = 0x7f08009c

.field public static split_action_bar:I = 0x7f08009e

.field public static src_atop:I = 0x7f08009f

.field public static src_in:I = 0x7f0800a0

.field public static src_over:I = 0x7f0800a1

.field public static submenuarrow:I = 0x7f0800a3

.field public static submit_area:I = 0x7f0800a4

.field public static tabMode:I = 0x7f0800a5

.field public static textSpacerNoButtons:I = 0x7f0800b5

.field public static textSpacerNoTitle:I = 0x7f0800b6

.field public static title:I = 0x7f0800b8

.field public static titleDividerNoCustom:I = 0x7f0800b9

.field public static title_template:I = 0x7f0800ba

.field public static topPanel:I = 0x7f0800bc

.field public static unchecked:I = 0x7f0800bd

.field public static uniform:I = 0x7f0800be

.field public static up:I = 0x7f0800bf

.field public static wrap_content:I = 0x7f0800c8


# direct methods
.method private constructor <init>()V
    .registers 1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
